
import React from 'react';
import { BarChart, Bar, XAxis, YAxis, CartesianGrid, Tooltip, Legend, ResponsiveContainer, Cell } from 'recharts';
import { ChartItem } from '../types';

interface BarChartComponentProps {
  data: ChartItem[];
}

const BarChartComponent: React.FC<BarChartComponentProps> = ({ data }) => {
  if (!data || data.length === 0) {
    return <p className="text-slate-400">차트에 표시할 데이터가 없습니다.</p>;
  }
  
  const CustomTooltip: React.FC<any> = ({ active, payload, label }) => {
    if (active && payload && payload.length) {
      return (
        <div className="bg-slate-700 p-3 rounded-md shadow-lg border border-slate-600">
          <p className="label text-sky-400 font-semibold">{`${label}`}</p>
          <p className="intro text-slate-200">{`값 : ${payload[0].value}`}</p>
        </div>
      );
    }
    return null;
  };

  return (
    <ResponsiveContainer width="100%" height={400}>
      <BarChart
        data={data}
        margin={{
          top: 20,
          right: 30,
          left: 0,
          bottom: 20, // Increased bottom margin for tilted labels
        }}
      >
        <CartesianGrid strokeDasharray="3 3" stroke="#475569" />
        <XAxis 
          dataKey="name" 
          stroke="#94a3b8" 
          angle={-30} // Tilt labels
          textAnchor="end" // Anchor tilted labels correctly
          height={70} // Increase height for XAxis to accommodate tilted labels
          interval={0} // Show all labels
          tick={{ fontSize: 12 }}
        />
        <YAxis stroke="#94a3b8" allowDecimals={false} />
        <Tooltip content={<CustomTooltip />} cursor={{ fill: 'rgba(71, 85, 105, 0.5)' }}/>
        <Legend wrapperStyle={{ color: '#e2e8f0', paddingTop: '20px' }} />
        <Bar dataKey="value" name="발표 횟수" unit="회" radius={[4, 4, 0, 0]}>
          {data.map((entry, index) => (
            <Cell key={`cell-${index}`} fill={entry.color} />
          ))}
        </Bar>
      </BarChart>
    </ResponsiveContainer>
  );
};

export default BarChartComponent;
