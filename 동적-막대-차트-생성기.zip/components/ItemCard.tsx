
import React, { useState, useEffect } from 'react';
import { ChartItem } from '../types';
import TrashIcon from './icons/TrashIcon';
import PlusIcon from './icons/PlusIcon';
import MinusIcon from './icons/MinusIcon'; // Assuming you'll create this

interface ItemCardProps {
  item: ChartItem;
  onNameChange: (id: string, newName: string) => void;
  onIncrementValue: (id: string) => void;
  onDecrementValue: (id: string) => void;
  onValueChange: (id: string, newValue: number) => void;
  onDeleteItem: (id: string) => void;
}

const ItemCard: React.FC<ItemCardProps> = ({ item, onNameChange, onIncrementValue, onDecrementValue, onValueChange, onDeleteItem }) => {
  const [name, setName] = useState<string>(item.name);
  const [isEditingName, setIsEditingName] = useState<boolean>(false);

  useEffect(() => {
    setName(item.name);
  }, [item.name]);

  const handleNameBlur = () => {
    if (name.trim() === '') {
      setName(item.name); // Revert if empty
    } else if (name !== item.name) {
      onNameChange(item.id, name.trim());
    }
    setIsEditingName(false);
  };
  
  const handleNameKeyDown = (e: React.KeyboardEvent<HTMLInputElement>) => {
    if (e.key === 'Enter') {
      handleNameBlur();
    } else if (e.key === 'Escape') {
      setName(item.name);
      setIsEditingName(false);
    }
  };

  const handleValueInputChange = (e: React.ChangeEvent<HTMLInputElement>) => {
    const newValue = parseInt(e.target.value, 10);
    if (!isNaN(newValue)) {
      onValueChange(item.id, newValue);
    } else if (e.target.value === '') {
       onValueChange(item.id, 0); // Allow clearing to 0
    }
  };


  return (
    <div className="bg-slate-700 p-4 rounded-lg shadow-lg border border-slate-600 hover:shadow-sky-500/30 transition-shadow duration-300">
      <div className="flex items-center justify-between mb-3">
        {isEditingName ? (
          <input
            type="text"
            value={name}
            onChange={(e) => setName(e.target.value)}
            onBlur={handleNameBlur}
            onKeyDown={handleNameKeyDown}
            autoFocus
            className="text-lg font-semibold bg-slate-600 text-sky-300 px-2 py-1 rounded-md flex-grow outline-none ring-2 ring-sky-500"
          />
        ) : (
          <h3 
            className="text-lg font-semibold text-sky-300 truncate cursor-pointer hover:underline" 
            onClick={() => setIsEditingName(true)}
            title="이름 변경하려면 클릭"
            style={{ color: item.color }}
          >
            {item.name}
          </h3>
        )}
        <button
          onClick={() => onDeleteItem(item.id)}
          className="text-slate-400 hover:text-red-500 transition-colors p-1 rounded-full hover:bg-slate-600"
          title="항목 삭제"
        >
          <TrashIcon className="w-5 h-5" />
        </button>
      </div>

      <div className="flex items-center justify-between gap-2">
        <div className="flex items-center gap-2">
          <button
            onClick={() => onDecrementValue(item.id)}
            className="p-2 bg-rose-500 hover:bg-rose-600 text-white rounded-md transition-colors shadow"
            title="값 감소"
          >
            <MinusIcon className="w-4 h-4" />
          </button>
          
          <input
            type="number"
            value={item.value.toString()} // Control component with string value
            onChange={handleValueInputChange}
            min="0"
            className="w-16 text-center py-1.5 px-2 bg-slate-600 border border-slate-500 rounded-md text-slate-100 focus:ring-1 focus:ring-sky-500 focus:border-sky-500 outline-none [appearance:textfield] [&::-webkit-outer-spin-button]:appearance-none [&::-webkit-inner-spin-button]:appearance-none"
          />

          <button
            onClick={() => onIncrementValue(item.id)}
            className="p-2 bg-emerald-500 hover:bg-emerald-600 text-white rounded-md transition-colors shadow"
            title="값 증가"
          >
            <PlusIcon className="w-4 h-4" />
          </button>
        </div>
        <span className="text-2xl font-bold text-slate-100">{item.value} <span className="text-sm text-slate-400">회</span></span>
      </div>
    </div>
  );
};

export default ItemCard;
