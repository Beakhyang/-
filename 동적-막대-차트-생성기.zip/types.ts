
export interface ChartItem {
  id: string;
  name: string;
  value: number;
  color: string;
}
