
import React, { useState, useCallback } from 'react';
import { ChartItem } from './types';
import BarChartComponent from './components/BarChartComponent';
import ItemCard from './components/ItemCard';
import PlusIcon from './components/icons/PlusIcon';

const INITIAL_ITEMS: ChartItem[] = [
  { id: '1', name: '발표자 A', value: 1, color: '#8884d8' },
  { id: '2', name: '발표자 B', value: 3, color: '#82ca9d' },
];

const PRESET_COLORS = ['#8884d8', '#82ca9d', '#ffc658', '#ff8042', '#0088FE', '#00C49F', '#FFBB28', '#FF8042'];

const App: React.FC = () => {
  const [items, setItems] = useState<ChartItem[]>(INITIAL_ITEMS);
  const [newItemName, setNewItemName] = useState<string>('');

  const getNextColor = useCallback(() => {
    return PRESET_COLORS[items.length % PRESET_COLORS.length];
  }, [items.length]);

  const handleAddItem = useCallback(() => {
    if (newItemName.trim() === '') {
      alert('항목 이름을 입력해주세요.');
      return;
    }
    const newItem: ChartItem = {
      id: `item-${Date.now()}`,
      name: newItemName.trim(),
      value: 0,
      color: getNextColor(),
    };
    setItems(prevItems => [...prevItems, newItem]);
    setNewItemName('');
  }, [newItemName, getNextColor]);

  const handleDeleteItem = useCallback((id: string) => {
    setItems(prevItems => prevItems.filter(item => item.id !== id));
  }, []);

  const handleItemNameChange = useCallback((id: string, newName: string) => {
    setItems(prevItems =>
      prevItems.map(item => (item.id === id ? { ...item, name: newName } : item))
    );
  }, []);

  const handleIncrementValue = useCallback((id: string) => {
    setItems(prevItems =>
      prevItems.map(item =>
        item.id === id ? { ...item, value: item.value + 1 } : item
      )
    );
  }, []);
  
  const handleDecrementValue = useCallback((id: string) => {
    setItems(prevItems =>
      prevItems.map(item =>
        item.id === id ? { ...item, value: Math.max(0, item.value - 1) } : item
      )
    );
  }, []);

  const handleValueChange = useCallback((id: string, newValue: number) => {
    setItems(prevItems =>
      prevItems.map(item =>
        item.id === id ? { ...item, value: Math.max(0, newValue) } : item
      )
    );
  }, []);


  return (
    <div className="min-h-screen bg-gradient-to-br from-slate-900 via-slate-800 to-indigo-900 text-slate-100 p-4 sm:p-6 md:p-8 flex flex-col items-center">
      <header className="mb-8 text-center">
        <h1 className="text-4xl sm:text-5xl font-bold text-transparent bg-clip-text bg-gradient-to-r from-sky-400 to-fuchsia-500">
          동적 데이터 시각화 도구
        </h1>
        <p className="text-slate-400 mt-2 text-lg">데이터를 입력하고 실시간으로 변화하는 그래프를 확인하세요.</p>
      </header>

      <div className="w-full max-w-6xl mx-auto flex flex-col lg:flex-row gap-8">
        {/* Controls and Item List Section */}
        <div className="lg:w-1/3 bg-slate-800 p-6 rounded-xl shadow-2xl space-y-6 border border-slate-700">
          <h2 className="text-2xl font-semibold text-sky-400 mb-4">항목 관리</h2>
          
          <div className="flex gap-2 items-end">
            <div className="flex-grow">
              <label htmlFor="newItemName" className="block text-sm font-medium text-slate-300 mb-1">새 항목 이름</label>
              <input
                id="newItemName"
                type="text"
                value={newItemName}
                onChange={(e) => setNewItemName(e.target.value)}
                placeholder="예: 프로젝트 알파"
                className="w-full px-4 py-2.5 bg-slate-700 border border-slate-600 rounded-lg focus:ring-2 focus:ring-sky-500 focus:border-sky-500 outline-none transition-all duration-200"
              />
            </div>
            <button
              onClick={handleAddItem}
              className="px-4 py-2.5 bg-sky-500 hover:bg-sky-600 text-white font-semibold rounded-lg shadow-md hover:shadow-lg transition-all duration-200 flex items-center gap-2 h-fit"
              title="새 항목 추가"
            >
              <PlusIcon className="w-5 h-5" />
              <span>추가</span>
            </button>
          </div>

          {items.length === 0 ? (
            <p className="text-slate-400 text-center py-4">항목이 없습니다. 새 항목을 추가해주세요.</p>
          ) : (
            <div className="space-y-4 max-h-[calc(100vh-350px)] overflow-y-auto pr-2">
              {items.map(item => (
                <ItemCard
                  key={item.id}
                  item={item}
                  onNameChange={handleItemNameChange}
                  onIncrementValue={handleIncrementValue}
                  onDecrementValue={handleDecrementValue}
                  onValueChange={handleValueChange}
                  onDeleteItem={handleDeleteItem}
                />
              ))}
            </div>
          )}
        </div>

        {/* Chart Section */}
        <div className="lg:w-2/3 bg-slate-800 p-6 rounded-xl shadow-2xl border border-slate-700 min-h-[400px] flex items-center justify-center">
          {items.length > 0 ? (
            <BarChartComponent data={items} />
          ) : (
            <div className="text-center text-slate-500">
              <p className="text-2xl">표시할 데이터가 없습니다.</p>
              <p>왼쪽 패널에서 항목을 추가하여 차트를 생성하세요.</p>
            </div>
          )}
        </div>
      </div>
      <footer className="mt-12 text-center text-slate-500 text-sm">
        <p>&copy; {new Date().getFullYear()} 동적 차트 생성기. 모든 권리 보유.</p>
      </footer>
    </div>
  );
};

export default App;
